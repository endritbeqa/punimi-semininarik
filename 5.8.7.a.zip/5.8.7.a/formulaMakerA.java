public class formulaMakerA// kjo klas merr si argument nje numer dhe e kthen rezultatin e funksionit
{public int formula(int x)
 {int f=x*x;
 return f;
 }
}
