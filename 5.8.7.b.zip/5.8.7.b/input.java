import javax.swing.*;

public class input
{public input(){}
 
  public int gjatsia()
   {int a = new Integer(JOptionPane.showInputDialog("vlera e madhesis se boshtit")).intValue();
    return a;
   }  
}









